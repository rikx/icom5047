package com.rener.sea;

public interface DetailsFragment {

	boolean onDetailsChanged();

}
